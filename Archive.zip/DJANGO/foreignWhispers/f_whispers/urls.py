from django.urls import path

from .views import translate_video, index

urlpatterns = [
    path("", index, name="index"),
    path('translate_video', translate_video, name='translate_video'),
]