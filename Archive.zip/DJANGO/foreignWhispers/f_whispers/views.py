from django.shortcuts import render

from django import forms

class VideoForm(forms.Form):
    videoInput = forms.FileField()
    languageSelect = forms.CharField(max_length=100)


def translate_video(request):
    if request.method == 'POST':
        print("POST") 
        form = VideoForm(request.POST, request.FILES)
        print(form)
        return render(request, "index.html", {'translated_text': 'translated_text'})

def index(request):
    context ={} 
    context['form']= VideoForm()
    return render(request, "index.html", context)



def translate_and_generate_subtitles(video_url, target_language):
    # Implement translation logic using googletrans
    # This is a placeholder, replace it with your actual implementation
    #download video from youtube

    translator = Translator()
    translated_text = translator.translate(original_text, dest=target_language).text

    # Use translated_text in your application logic
    return translated_text


def translate_text(text, target_language):
    translator = Translator()
    #slice all text on the basis of sentences and translate each sentence
    text = nltk.sent_tokenize(text)
    translation = ""
    for i in text:
        translation = translation + translator.translate(i, dest=target_language).text + "."
    return translation

def text_to_speech(translated_text, target_language):
    # Convert translated text to speech using gTTS
    tts = gTTS(text=translated_text, lang=target_language, slow=False)
    return tts


def extract_audio(video_path, audio_output_path):
    # Command to extract audio using ffmpeg
    command = f"ffmpeg -i \"{video_path}\" -ab 160k -ac 2 -ar 44100 -vn \"{audio_output_path}\""
    try:
        output = subprocess.check_output(command, stderr=subprocess.STDOUT, shell=True)
        print(output.decode('utf-8'))
    except subprocess.CalledProcessError as e:
        print(f"Error occurred: {e.output.decode('utf-8')}")

def transcribe_audio(audio_path):
    # Load audio and run the Whisper model to transcribe it
    result = model.transcribe(audio_path)
    return result['text']

# Directory where the videos are saved


# def text_to_speech(translated_text):
#     # Convert translated text to speech using pyttsx3
#     engine = pyttsx3.init()
#     engine.say(translated_text)
#     engine.runAndWait()


